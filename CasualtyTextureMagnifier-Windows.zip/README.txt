﻿Casualty Texture Magnifier
ZIP 전체를 풀고 실행하세요. 기본 샘플로 시작하거나 CustomSprites 폴더를 여세요.
공개 버전에는 게임 원본 텍스처와 애니메이션 데이터가 들어 있지 않습니다.
Extract the entire ZIP and launch the app. Use the original sample or open your own CustomSprites folder. Game assets are not included.
Made with Codex.
