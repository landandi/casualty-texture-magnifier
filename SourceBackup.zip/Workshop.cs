﻿using System;using System.IO;using System.Drawing;using System.Drawing.Drawing2D;using System.Windows.Forms;using System.Collections.Generic;using System.Diagnostics;using System.Linq;
class App:Form{
static readonly Dictionary<string,string> Words=new Dictionary<string,string>{{"캐주얼티 스킨 작업실","Skin Workshop"},{"●  조립 미리보기    /    PNG 저장 시 자동 갱신","●  ASSEMBLED PREVIEW  /  UPDATES ON PNG SAVE"},{"텍스처 폴더 열기","Open textures"},{"클튜에서 열기","Open in Clip Studio"},{"Aseprite에서 열기","Open in Aseprite"},{"텍스처 폴더를 선택하세요.","Choose a texture folder."},{"부위 위에 마우스를 올리면 파일명이 표시됩니다.","Hover over a part to see its filename."},{"선택: ","Selected: "},{"CustomSprites 또는 Body 폴더를 가진 스킨 팩 선택","Choose CustomSprites or a skin pack with a Body folder"},{"Body 폴더가 들어 있는 스킨 팩을 찾지 못했습니다.","No skin packs with a Body folder were found."},{"조립 가능한 텍스처를 찾지 못했습니다.","No compatible sprites found."},{"부위를 클릭하면 편집할 수 있어요.","Click a part to edit it."},{"먼저 캐릭터 부위를 클릭하세요.","Select a character part first."},{" 실행 파일 선택"," executable"},{"편집본: ","Working copy: "},{"꼬리","Tail"},{"뒤 위팔","Back upper arm"},{"뒤 아래팔","Back forearm"},{"뒤 손","Back hand"},{"뒤 허벅지","Back thigh"},{"뒤 종아리","Back shin"},{"뒤 발","Back foot"},{"복부","Abdomen"},{"상체","Upper torso"},{"앞 허벅지","Front thigh"},{"앞 종아리","Front shin"},{"앞 발","Front foot"},{"앞 위팔","Front upper arm"},{"앞 아래팔","Front forearm"},{"앞 손","Front hand"},{"머리","Head"},{"눈","Eyes"}};
static string Pref=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"CasualtySkinViewer","language.txt");
static bool English=ReadLanguage();
static bool ReadLanguage(){try{return File.Exists(Pref)?File.ReadAllText(Pref).Trim()=="en":System.Globalization.CultureInfo.CurrentUICulture.TwoLetterISOLanguageName!="ko";}catch{return false;}}
static string L(string k){string v;return English&&Words.TryGetValue(k,out v)?v:k;}
Dictionary<Control,string> localized=new Dictionary<Control,string>();
ComboBox language=new ComboBox();
void Bind(Control c,string k){localized[c]=k;c.Text=L(k);}
void SwitchLanguage(){English=language.SelectedIndex==1;UpdateMotionText();UpdateFace();UpdateInteraction();foreach(var c in localized)c.Key.Text=L(c.Value);path.Text=root??L("텍스처 폴더를 선택하세요.");status.Text=picked==null?L("부위 위에 마우스를 올리면 파일명이 표시됩니다."):L("선택: ")+picked.Label;try{Directory.CreateDirectory(Path.GetDirectoryName(Pref));File.WriteAllText(Pref,English?"en":"ko");}catch(IOException){}catch(UnauthorizedAccessException){}}

Color bg=Color.FromArgb(24,22,24), panel=Color.FromArgb(38,33,36), ink=Color.FromArgb(234,225,213), accent=Color.FromArgb(241,127,118);
ComboBox packs=new ComboBox(); Label status=new Label(), path=new Label(); Canvas scene=new Canvas(); string root; Layer picked; Timer timer=new Timer();
class Layer{public string File,Part,Sprite,Copy,Key;public string Label{get{return L(Part)+"  /  "+Sprite;}}public int X,Y;public float Dx,Dy;public Bitmap Img;}
class Canvas:Panel{public Canvas(){DoubleBuffered=true;}}
List<Layer> parts=new List<Layer>();
[STAThread] static void Main(string[] args){Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);using(var a=new App()){if(args.Length>1&&args[0]=="--check"){a.LoadRoot(args[1]);if(a.parts.Count!=17||a.parts.Any(l=>l.Img==null))Environment.Exit(1);return;}Application.Run(a);}}
Label TextLabel(string t,int x,int y,int w,int h,float size,Color color){var l=new Label{Text=t,Bounds=new Rectangle(x,y,w,h),ForeColor=color,Font=new Font("Malgun Gothic",size)};Controls.Add(l);return l;}
Button Btn(string t,int x,int w,Action f){var b=new Button{Text=t,Bounds=new Rectangle(x,89,w,35),FlatStyle=FlatStyle.Flat,BackColor=panel,ForeColor=ink};b.FlatAppearance.BorderColor=Color.FromArgb(105,73,78);b.Click+=(o,e)=>f();Controls.Add(b);Bind(b,t);return b;}
App(){
Text="Casualty Texture Magnifier";ClientSize=new Size(920,700);MinimumSize=new Size(770,540);BackColor=bg;ForeColor=ink;Font=new Font("Malgun Gothic",9);Icon=Icon.ExtractAssociatedIcon(Application.ExecutablePath);
TextLabel("CASUALTY TEXTURE MAGNIFIER",22,17,650,42,21,ink);Bind(TextLabel("",24,61,680,25,10,accent),"●  조립 미리보기    /    PNG 저장 시 자동 갱신");
Btn("텍스처 폴더 열기",24,145,Browse);packs.SetBounds(179,92,180,31);packs.DropDownStyle=ComboBoxStyle.DropDownList;packs.BackColor=panel;packs.ForeColor=ink;packs.SelectedIndexChanged+=(o,e)=>Build();Controls.Add(packs);
Btn("클튜에서 열기",369,130,()=>Edit(true));Btn("Aseprite에서 열기",509,154,()=>Edit(false));
path=TextLabel("텍스처 폴더를 선택하세요.",24,134,865,26,9,ink);path.AutoEllipsis=true;path.Text=L(path.Text);language.SetBounds(674,92,90,30);language.DropDownStyle=ComboBoxStyle.DropDownList;language.Items.AddRange(new object[]{"한국어","English"});language.SelectedIndex=English?1:0;language.SelectedIndexChanged+=(o,e)=>SwitchLanguage();Controls.Add(language);
LoadGameMotion();SetupMotion();scene.SetBounds(24,235,872,397);scene.Anchor=AnchorStyles.Top|AnchorStyles.Bottom|AnchorStyles.Left|AnchorStyles.Right;scene.BackColor=panel;Controls.Add(scene);
status=TextLabel(L("부위 위에 마우스를 올리면 파일명이 표시됩니다."),24,646,860,28,10,accent);status.Anchor=AnchorStyles.Bottom|AnchorStyles.Left|AnchorStyles.Right;status.AutoEllipsis=true;status.Text=L(status.Text);
scene.Paint+=(o,e)=>Draw(e.Graphics);scene.MouseMove+=(o,e)=>{var a=Hit(e.Location);status.Text=a==null?(picked==null?"부위 위에 마우스를 올려보세요.":L("선택: ")+picked.Label):a.Label;};SetupInteraction();scene.Resize+=(o,e)=>scene.Invalidate();
timer.Interval=650;timer.Tick+=(o,e)=>Sync();timer.Start();FormClosed+=(o,e)=>{timer.Stop();foreach(var l in parts)if(l.Img!=null)l.Img.Dispose();};
Words["기본 캐릭터"]="Default characters";var starter=Btn("기본 캐릭터",589,153,LoadStarter);starter.Top=195;starter.Height=31;LoadStarter();
}
void LoadStarter(){var dir=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"OfficialPacks");if(Directory.Exists(dir))LoadRoot(dir);else if(Directory.Exists(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"StarterPack","Body")))LoadRoot(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"StarterPack"));else status.Text=English?"Extract the entire ZIP first.":"ZIP 전체를 먼저 압축 해제하세요.";} void Browse(){using(var f=new FolderBrowserDialog()){f.Description=L("CustomSprites 또는 Body 폴더를 가진 스킨 팩 선택");if(root!=null)f.SelectedPath=root;if(f.ShowDialog(this)==DialogResult.OK)LoadRoot(f.SelectedPath);}}
void LoadRoot(string dir){var folders=Directory.Exists(Path.Combine(dir,"Body"))?new[]{dir}:Directory.GetDirectories(dir).Where(p=>Directory.Exists(Path.Combine(p,"Body"))).OrderBy(p=>p).ToArray();if(folders.Length==0){status.Text=L("Body 폴더가 들어 있는 스킨 팩을 찾지 못했습니다.");return;}root=dir;path.Text=dir;packs.DataSource=folders.Select(p=>new DirectoryInfo(p)).ToList();packs.DisplayMember="Name";Build();}
void Build(){foreach(var l in parts)if(l.Img!=null)l.Img.Dispose();parts.Clear();picked=null;ResetPose();var pack=packs.SelectedItem as DirectoryInfo;if(pack==null)return;
foreach(var line in "Tail,꼬리,39,33;UpArm,뒤 위팔,34,29;DownArm,뒤 아래팔,33,37;HandB,뒤 손,32,49;Thigh,뒤 허벅지,40,45;Crus,뒤 종아리,41,55;Foot,뒤 발,40,62;DownTorso,복부,38,36;UpTorso,상체,38,27;Thigh,앞 허벅지,35,45;Crus,앞 종아리,35,55;Foot,앞 발,34,62;UpArm,앞 위팔,44,28;DownArm,앞 아래팔,45,37;HandF,앞 손,44,49;Head,머리,29,18;EyeOpen,눈,29,18".Split(';')){
var a=line.Split(',');foreach(var g in new[]{"Head","Body"}){string name="experiment"+a[0]+".png",f=Path.Combine(pack.FullName,g,name);if(!File.Exists(f))continue;
parts.Add(new Layer{File=f,Copy=Path.Combine(pack.FullName,"..","편집본",pack.Name,g,name),Part=a[1],Sprite=g+"\\"+name,X=int.Parse(a[2])+(pack.Name=="Milky"&&(a[0]=="Head"||a[0].StartsWith("Eye"))?6:pack.Name=="Dune"&&(a[0]=="Head"||a[0].StartsWith("Eye"))?3:pack.Name=="Milky"&&a[0]=="UpTorso"?-4:0),Y=int.Parse(a[3])+(pack.Name=="Milky"&&(a[0]=="Head"||a[0].StartsWith("Eye"))?-2:pack.Name=="Dune"&&(a[0]=="Head"||a[0].StartsWith("Eye"))?-12:0)});break;}}
status.Text=parts.Count==0?L("조립 가능한 텍스처를 찾지 못했습니다."):L("부위를 클릭하면 편집할 수 있어요.");SetFace();Sync();scene.Invalidate();}
void Sync(){bool change=false;foreach(var l in parts){try{string f=File.Exists(l.Copy)?l.Copy:l.File;var fi=new FileInfo(f);string key=f+fi.LastWriteTimeUtc.Ticks+"/"+fi.Length;if(key==l.Key)continue;using(var ms=new MemoryStream(File.ReadAllBytes(f)))using(var b=new Bitmap(ms)){var next=new Bitmap(b);if(l.Img!=null)l.Img.Dispose();l.Img=next;l.Key=key;change=true;}}catch(IOException){}catch(ArgumentException){}}if(change)scene.Invalidate();}
int ScalePx{get{return Math.Max(1,Math.Min(scene.Width/88,scene.Height/86));}}
Point Origin{get{return new Point((scene.Width-88*ScalePx)/2,(scene.Height-86*ScalePx)/2);}}
void Draw(Graphics g){int s=ScalePx;var p=Origin;using(var pen=new Pen(Color.FromArgb(49,41,45))) {for(int x=0;x<scene.Width;x+=24)g.DrawLine(pen,x,0,x,scene.Height);for(int y=0;y<scene.Height;y+=24)g.DrawLine(pen,0,y,scene.Width,y);}
g.InterpolationMode=InterpolationMode.NearestNeighbor;g.PixelOffsetMode=PixelOffsetMode.Half;
g.TranslateTransform(p.X,p.Y);g.ScaleTransform(s,s);g.TranslateTransform(world.X,world.Y);using(var tm=TailTransform())g.MultiplyTransform(tm,MatrixOrder.Prepend);
foreach(var l in parts){if(l.Img==null)continue;var state=g.Save();using(var pose=Pose(l))g.MultiplyTransform(pose,MatrixOrder.Prepend);
var r=new RectangleF(l.X+l.Dx,l.Y+l.Dy,l.Img.Width,l.Img.Height);g.DrawImage(l.Img,r,new RectangleF(0,0,l.Img.Width,l.Img.Height),GraphicsUnit.Pixel);if(l==picked)using(var pen=new Pen(accent,0.3f))g.DrawRectangle(pen,r.X,r.Y,r.Width,r.Height);g.Restore(state);}
DrawBlood(g);}
Layer Hit(Point q){var p=Origin;int s=ScalePx;for(int i=parts.Count-1;i>=0;i--){var l=parts[i];var xy=new[]{new PointF((q.X-p.X)/(float)s-world.X,(q.Y-p.Y)/(float)s-world.Y)};using(var tm=TailTransform()){tm.Invert();tm.TransformPoints(xy);}using(var pose=Pose(l)){pose.Invert();pose.TransformPoints(xy);}int x=(int)Math.Floor(xy[0].X-l.X-l.Dx),y=(int)Math.Floor(xy[0].Y-l.Y-l.Dy);if(l.Img!=null&&x>=0&&y>=0&&x<l.Img.Width&&y<l.Img.Height&&l.Img.GetPixel(x,y).A>0)return l;}return null;}
void Edit(bool clip){if(picked==null){status.Text=L("먼저 캐릭터 부위를 클릭하세요.");return;}try{var key=clip?"ClipStudio":"Aseprite";var cfg=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"CasualtySkinViewer",key+".txt");
var exe=File.Exists(cfg)?File.ReadAllText(cfg).Trim():clip?Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),@"CELSYS\CLIP STUDIO 1.5\CLIP STUDIO PAINT\CLIPStudioPaint.exe"):Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),@"Steam\steamapps\common\Aseprite\Aseprite.exe");
if(!File.Exists(exe)){using(var f=new OpenFileDialog{Title=key+L(" 실행 파일 선택"),Filter=(English?"Executables":"실행 파일")+"|*.exe"}){if(f.ShowDialog(this)!=DialogResult.OK)return;exe=f.FileName;}Directory.CreateDirectory(Path.GetDirectoryName(cfg));File.WriteAllText(cfg,exe);}
var copy=Path.GetFullPath(picked.Copy);Directory.CreateDirectory(Path.GetDirectoryName(copy));if(!File.Exists(copy))File.Copy(picked.File,copy);Process.Start(exe,"\""+copy+"\"");status.Text=L("편집본: ")+copy;
}catch(Exception e){status.Text=e.Message;}}

ComboBox motion=new ComboBox(); CheckBox bleed=new CheckBox(), pause=new CheckBox(); Timer frames=new Timer(); Stopwatch clock=Stopwatch.StartNew(); double frame;
void SetupMotion(){
 Words["기본 자세"]="Idle";Words["앉기"]="Sit";Words["달리기"]="Run";Words["넘어짐"]="Fall";Words["기상"]="Get up";Words["걷기"]="Walk";Words["공격"]="Attack";Words["출혈"]="Bleeding";Words["일시 정지"]="Pause";Words["작업용 모션 · 게임 원본 애니메이션 아님"]="Preview motions / not original game animations";
 motion.SetBounds(24,160,145,30);motion.DropDownStyle=ComboBoxStyle.DropDownList;Controls.Add(motion);UpdateMotionText();
 motion.SelectedIndexChanged+=(o,e)=>{if(updatingMotion)return;clock.Restart();frame=0;scene.Invalidate();};
 bleed.SetBounds(181,161,88,28);pause.SetBounds(278,161,100,28);Controls.Add(bleed);Controls.Add(pause);Bind(bleed,"출혈");Bind(pause,"일시 정지");
 Bind(TextLabel("",394,163,350,25,9,accent),gameFrames==null?"작업용 모션 · 게임 원본 애니메이션 아님":"게임 클립 기반 · 편집용 미리보기");
 bleed.CheckedChanged+=(o,e)=>scene.Invalidate();pause.CheckedChanged+=(o,e)=>clock.Restart();
 frames.Interval=33;frames.Tick+=(o,e)=>{if(!pause.Checked){float dt=(float)Math.Min(.05,clock.Elapsed.TotalSeconds);MovePhysics(dt);TailStep(dt);}if(!pause.Checked&&((gameFrames!=null||motion.SelectedIndex>0&&motion.SelectedIndex!=3)||bleed.Checked)){frame+=Math.Min(.1,clock.Elapsed.TotalSeconds);scene.Invalidate();}clock.Restart();};frames.Start();FormClosed+=(o,e)=>frames.Dispose();
}
bool updatingMotion;
void UpdateMotionText(){if(motion.Items.Count==0&&motion.Parent==null)return;int i=Math.Max(0,motion.SelectedIndex);double time=frame;updatingMotion=true;motion.Items.Clear();motion.Items.AddRange(new object[]{L("기본 자세"),L(gameFrames==null?"걷기":"걷기 (달리기 클립 저속)"),L("공격"),L("앉기"),L("달리기"),L(gameFrames==null?"넘어짐":"눕기"),L(gameFrames==null?"기상":"일어나기 (역재생)")});motion.SelectedIndex=i;frame=time;updatingMotion=false;}
Matrix Pose(Layer l){
 if(gameFrames!=null){bool fixedRig=interaction.SelectedIndex>0||joints.Count>0||motion.SelectedIndex<=0;var gm=GamePose(l,fixedRig);if(fixedRig)using(var edit=Manual(l))gm.Multiply(edit,MatrixOrder.Append);return gm;}var m=new Matrix();if(interaction.SelectedIndex>0||joints.Count>0){m.Dispose();return Manual(l);}if(motion.SelectedIndex<=0)return m;
 bool front=l.Part.StartsWith("앞"), back=l.Part.StartsWith("뒤");
 bool arm=l.Part.Contains("팔")||l.Part.Contains("손"),leg=l.Part.Contains("허벅지")||l.Part.Contains("종아리")||l.Part.Contains("발");
 double wave=Math.Sin(frame*(motion.SelectedIndex==4?15:8)), t=(frame%1.15)/1.15;
 float angle=0;PointF pivot=new PointF(front?46:36,29);
 if((motion.SelectedIndex==1||motion.SelectedIndex==4)&&(front||back)){if(arm)angle=(float)(wave*(front?25:-25));if(leg){angle=(float)(wave*(front?-24:24));pivot=new PointF(front?38:43,46);}}
 if(motion.SelectedIndex==2&&arm&&front){angle=(float)(t<.24?30*t/.24:t<.38?30-132*(t-.24)/.14:t<.55?-102:-102*Math.Max(0,1-(t-.55)/.35));}
 if(motion.SelectedIndex==4)angle*=1.55f;
 if(motion.SelectedIndex==3){if(leg){angle=front?-66:63;pivot=new PointF(front?38:43,46);}if(arm)angle=front?-13:13;m.RotateAt(angle,pivot,MatrixOrder.Append);m.Translate(0,17,MatrixOrder.Append);return m;}
 if(motion.SelectedIndex>=5){double u=Math.Min(1,frame/.85);u=u*u*(3-2*u);if(motion.SelectedIndex==6)u=1-u;m.RotateAt((float)(-84*u),new PointF(42,46),MatrixOrder.Append);m.Translate(0,(float)(21*u),MatrixOrder.Append);return m;}
 m.RotateAt(angle,pivot,MatrixOrder.Append);
 float bob=(motion.SelectedIndex==1||motion.SelectedIndex==4)?(float)(-(motion.SelectedIndex==4?3:1.6)*Math.Abs(wave)):(float)(-2*Math.Sin(Math.PI*t));
 m.Translate(0,bob,MatrixOrder.Append);return m;
}
void DrawBlood(Graphics g){
 if(!bleed.Checked)return;
 using(var b=new SolidBrush(Color.FromArgb(216,184,45,54)))for(int j=0;j<7;j++){
 double t=(frame*1.2+j/7.0)%1;float x=(float)(42+Math.Sin(j*2.4)*12*t),y=(float)(32+38*t*t);g.FillRectangle(b,x,y,j%3==0?2:1,j%3==0?3:2);
 }
}

ComboBox face=new ComboBox();ComboBox interaction=new ComboBox();Layer drag; Point last; PointF world,velocity;bool grab,flying;long lastTick; readonly Stopwatch inputClock=Stopwatch.StartNew();
string[] faceKeys={"EyeOpen","EyeClosed","EyeHalfClosed","EyeHappy","EyeSad","EyePanic","EyeScared","EyeLookBack","EyeGone","EyeGoneHealed"};
string[] faceKo={"눈 뜸","눈 감음","반쯤 감음","기쁨","슬픔","당황","겁먹음","뒤돌아봄","눈 부상","눈 부상 회복"};
bool updatingInteraction;void UpdateInteraction(){int i=Math.Max(0,interaction.SelectedIndex);updatingInteraction=true;interaction.Items.Clear();interaction.Items.AddRange(new object[]{L("포즈 변경"),L("인형 흔들기"),L("던지기 모드")});interaction.SelectedIndex=i;updatingInteraction=false;} void SetupInteraction(){
 string[] en={"Open eyes","Closed eyes","Half closed","Happy","Sad","Panic","Scared","Look back","Eye injury","Healed eye"};
 for(int i=0;i<en.Length;i++)Words[faceKo[i]]=en[i];
 Words["인형 흔들기"]="Ragdoll grab";Words["표정"]="Expression";Words["던지기 모드"]="Throw mode";Words["자세 초기화"]="Reset pose";
 Bind(TextLabel("",24,200,79,26,9,ink),"표정");
 face.SetBounds(103,197,155,28);face.DropDownStyle=ComboBoxStyle.DropDownList;Controls.Add(face);UpdateFace();
 face.SelectedIndexChanged+=(o,e)=>{if(!refreshFace)SetFace();};
 Words["포즈 변경"]="Pose edit";
 interaction.SetBounds(274,198,168,27);interaction.DropDownStyle=ComboBoxStyle.DropDownList;Controls.Add(interaction);UpdateInteraction();
 interaction.SelectedIndexChanged+=(o,e)=>{if(updatingInteraction)return;drag=null;grab=false;flying=false;tailGrab=false;tailDrop=false;scene.Capture=false;velocity=PointF.Empty;if(interaction.SelectedIndex==0){world=PointF.Empty;tailAngle=tailSpin=0;}scene.Invalidate();};
var reset=Btn("자세 초기화",452,126,ResetPose);reset.Top=195;reset.Height=31;
 scene.MouseDown+=(o,e)=>{if(e.Button!=MouseButtons.Left)return;picked=Hit(e.Location);if(picked==null)return;drag=picked;grab=interaction.SelectedIndex==2;flying=false;tailDrop=false;if(grab){tailAngle=0;tailSpin=0;}BeginTail(e.Location);velocity=PointF.Empty;last=e.Location;lastTick=inputClock.ElapsedMilliseconds;scene.Capture=true;scene.Invalidate();};
 scene.MouseMove+=(o,e)=>{if(drag==null)return;int scale=ScalePx;float dx=(e.X-last.X)/(float)scale,dy=(e.Y-last.Y)/(float)scale;if(dx==0&&dy==0)return;
 if(tailGrab){MoveTail(dx,dy);}else if(grab){world.X+=dx;world.Y+=dy;long now=inputClock.ElapsedMilliseconds;float dt=Math.Max(12,now-lastTick)/1000f;velocity=new PointF(Clamp(dx/dt,-160,160),Clamp(dy/dt,-160,160));lastTick=now;}
 else if(interaction.SelectedIndex==0){Bend(drag,last,e.Location);}last=e.Location;scene.Invalidate();};
 scene.MouseUp+=(o,e)=>{if(e.Button!=MouseButtons.Left||drag==null)return;if(tailGrab){tailGrab=false;tailDrop=true;velocity=PointF.Empty;}flying=grab&&inputClock.ElapsedMilliseconds-lastTick<140&&(Math.Abs(velocity.X)+Math.Abs(velocity.Y)>5);drag=null;grab=false;scene.Capture=false;};
 scene.MouseCaptureChanged+=(o,e)=>{if(!scene.Capture){if(tailGrab){tailGrab=false;tailDrop=true;velocity=PointF.Empty;}drag=null;grab=false;}};
}
bool refreshFace;
void UpdateFace(){int i=Math.Max(0,face.SelectedIndex);refreshFace=true;face.Items.Clear();face.Items.AddRange(faceKo.Select(L).Cast<object>().ToArray());face.SelectedIndex=i;refreshFace=false;}
void SetFace(){var l=parts.FirstOrDefault(p=>p.Part=="눈");var pack=packs.SelectedItem as DirectoryInfo;if(l==null||pack==null)return;int index=Math.Max(0,face.SelectedIndex);
 foreach(var key in new[]{faceKeys[index],"EyeOpen"})foreach(var folder in new[]{"Head","Body"}){
 string name="experiment"+key+".png",f=Path.Combine(pack.FullName,folder,name);if(!File.Exists(f))continue;
 l.File=f;l.Sprite=folder+"\\"+name;l.Copy=Path.Combine(pack.FullName,"..","편집본",pack.Name,folder,name);l.Key=null;Sync();scene.Invalidate();return;}
}
void ResetPose(){joints.Clear();heldArm=null;armSwing=legSwing=armSpeed=legSpeed=0;tailGrab=false;tailDrop=false;tailAngle=0;tailSpin=0;foreach(var l in parts){l.Dx=0;l.Dy=0;}world=PointF.Empty;velocity=PointF.Empty;flying=false;grab=false;drag=null;scene.Capture=false;scene.Invalidate();}
static float Clamp(float v,float min,float max){return Math.Min(max,Math.Max(min,v));}
void MovePhysics(double dt){if(!flying||dt<=0)return;float t=(float)dt;velocity.Y+=119*t;world.X+=velocity.X*t;world.Y+=velocity.Y*t;
 if(world.X<-31||world.X>12){world.X=Clamp(world.X,-31,12);velocity.X*=-.52f;}
 if(world.Y<-15){world.Y=-15;velocity.Y=Math.Abs(velocity.Y)*.52f;}
 if(world.Y>12){world.Y=12;velocity.Y*=-.39f;velocity.X*=.65f;if(Math.Abs(velocity.Y)<8){velocity=PointF.Empty;flying=false;}}
 scene.Invalidate();}

bool tailGrab, tailDrop; string heldArm;
float tailAngle, tailSpin, armSwing, legSwing, armSpeed, legSpeed;
PointF tailAnchor, tailCursor;
bool BeginTail(Point mouse){
 if(picked==null||interaction.SelectedIndex!=1)return false;
 var p=Origin;float s=ScalePx;
 tailCursor=new PointF((mouse.X-p.X)/s,(mouse.Y-p.Y)/s);
 var a=new[]{new PointF(tailCursor.X-world.X,tailCursor.Y-world.Y)};
 using(var inv=TailTransform()){inv.Invert();inv.TransformPoints(a);}
 heldArm=(picked.Part.Contains("팔")||picked.Part.Contains("손"))?picked.Part.Substring(0,1):null;tailAnchor=a[0];tailGrab=true;tailDrop=false;return true;
}
Matrix TailTransform(){var m=new Matrix();m.RotateAt(tailAngle,tailAnchor);return m;}
void MoveTail(float dx,float dy){
 tailCursor.X+=dx;tailCursor.Y+=dy;
 world=new PointF(tailCursor.X-tailAnchor.X,tailCursor.Y-tailAnchor.Y);
 tailSpin=Clamp(tailSpin-dx*22,-180,180);armSpeed=Clamp(armSpeed-dx*65-dy*22,-260,260);legSpeed=Clamp(legSpeed-dx*43+dy*15,-205,205);scene.Invalidate();
}
void TailStep(float dt){if(tailGrab||tailDrop){armSpeed+=(Clamp(-tailAngle*.66f,-25,25)-armSwing)*30*dt;legSpeed+=(Clamp(-tailAngle*.38f,-17,17)-legSwing)*17*dt;armSpeed*=(float)Math.Exp(-4.2*dt);legSpeed*=(float)Math.Exp(-3.3*dt);armSwing=Clamp(armSwing+armSpeed*dt,-52,52);legSwing=Clamp(legSwing+legSpeed*dt,-39,39);}
 if(tailGrab){
  float desired=heldArm==null?Clamp((tailAnchor.X-42)*1.5f,-20,30):Clamp((tailAnchor.X-42)*3.2f,-33,33);
  tailSpin+=(desired-tailAngle)*22*dt;tailSpin*=(float)Math.Exp(-5*dt);tailAngle=Clamp(tailAngle+tailSpin*dt,-45,45);scene.Invalidate();return;
 }
 if(!tailDrop)return;
 tailSpin+=(-tailAngle*26)*dt;tailSpin*=(float)Math.Exp(-5*dt);tailAngle+=tailSpin*dt;
 velocity.Y+=120*dt;world.Y+=velocity.Y*dt;
 float bottom=55;
 foreach(var l in parts){if(l.Img==null)continue;float x=l.X+l.Dx,y=l.Y+l.Dy,h=l.Img.Height,w=l.Img.Width;var corners=new[]{new PointF(x,y),new PointF(x+w,y),new PointF(x,y+h),new PointF(x+w,y+h)};
 using(var m=Pose(l))m.TransformPoints(corners);using(var m=TailTransform())m.TransformPoints(corners);
 foreach(var c in corners)bottom=Math.Max(bottom,c.Y);}
 float floor=82-bottom;
 if(world.Y>=floor){world.Y=floor;if(velocity.Y>0)velocity.Y*=-.25f;if(Math.Abs(velocity.Y)<4)velocity.Y=0;
 if(velocity.Y==0&&Math.Abs(tailAngle)<.15f&&Math.Abs(tailSpin)<.4f&&Math.Abs(armSwing)<.5f&&Math.Abs(legSwing)<.5f&&Math.Abs(armSpeed)<1&&Math.Abs(legSpeed)<1){tailDrop=false;tailAngle=0;}}
 scene.Invalidate();
}

Dictionary<string,float> joints=new Dictionary<string,float>();
string Limb(Layer l){if(l!=null&&l.Part=="꼬리")return "Tail";if(l==null||!(l.Part.StartsWith("앞")||l.Part.StartsWith("뒤")))return null;return l.Part.Substring(0,1)+(l.Part.Contains("팔")||l.Part.Contains("손")?"A":"L");}
bool Lower(Layer l){return l.Part!="꼬리"&&!l.Part.Contains("위팔")&&!l.Part.Contains("허벅지");}
PointF Pivot(string k,bool low){if(gameFrames!=null){bool front=k[0]=='앞';var v=gameFrames[0];if(k=="Tail")return TailAt(v[21],v[22],v[23]);int first=k[1]=='A'?(front?12:1):(front?9:4);int a=first*3,b=(first+1)*3;float q=low?.5f:-.5f;return new PointF(v[a]+(v[b]-v[a])*q,v[a+1]+(v[b+1]-v[a+1])*q);}if(k=="Tail")return new PointF(43,40);bool f=k[0]=='앞';return k[1]=='A'?(low?new PointF(f?47:35,38):new PointF(f?46:36,29)):(low?new PointF(f?37:43,55):new PointF(f?38:43,46));}
float Joint(string k){float v;return joints.TryGetValue(k,out v)?v:0;}
Matrix Manual(Layer l){var m=new Matrix();string k=Limb(l);if(k==null)return m;if(Lower(l))m.RotateAt(Joint(k+"2"),Pivot(k,true),MatrixOrder.Append);m.RotateAt(Joint(k+"1"),Pivot(k,false),MatrixOrder.Append);return m;}
bool Bend(Layer l,Point before,Point after){
 string k=Limb(l);if(k==null)return false;bool low=Lower(l);var p=Pivot(k,low);var a=new[]{p};if(low)using(var m=new Matrix()){m.RotateAt(Joint(k+"1"),Pivot(k,false));m.TransformPoints(a);}
 var o=Origin;float s=ScalePx;var pts=new[]{new PointF((before.X-o.X)/s-world.X,(before.Y-o.Y)/s-world.Y),new PointF((after.X-o.X)/s-world.X,(after.Y-o.Y)/s-world.Y)};
 using(var inv=TailTransform()){inv.Invert();inv.TransformPoints(pts);}
 double delta=(Math.Atan2(pts[1].Y-a[0].Y,pts[1].X-a[0].X)-Math.Atan2(pts[0].Y-a[0].Y,pts[0].X-a[0].X))*180/Math.PI;
 string key=k+(low?"2":"1");joints[key]=Joint(key)+(float)(((delta+540)%360)-180);return true;
}


float[][] gameFrames;float[] gameDuration;
static string[] rigParts={"꼬리","뒤 위팔","뒤 아래팔","뒤 손","뒤 허벅지","뒤 종아리","뒤 발","복부","상체","앞 허벅지","앞 종아리","앞 발","앞 위팔","앞 아래팔","앞 손","머리","눈"};
void LoadGameMotion(){
 var file=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"GameMotion.bin");if(!File.Exists(file))return;
 using(var r=new BinaryReader(File.OpenRead(file))){
 if(new string(r.ReadChars(4))!="CTM1")throw new InvalidDataException();
 gameFrames=new float[7][];gameDuration=new float[7];
 for(int i=0;i<7;i++){int n=r.ReadInt32();if(n<2||n>1024)throw new InvalidDataException();gameDuration[i]=r.ReadSingle();gameFrames[i]=new float[n*51];for(int j=0;j<n*51;j++)gameFrames[i][j]=r.ReadSingle();}
 if(r.BaseStream.Position!=r.BaseStream.Length)throw new InvalidDataException();
 }
 Words["걷기 (달리기 클립 저속)"]="Slow run";Words["눕기"]="Lie down";Words["일어나기 (역재생)"]="Get up (reverse)";Words["게임 클립 기반 · 편집용 미리보기"]="Game clips / editor preview";
 Words["작업용 모션 · 게임 원본 애니메이션 아님"]= "Game clips / editor preview";
}
PointF TailAt(float x,float y,float angle){double rad=angle*Math.PI/180;return new PointF(x-(float)(2.824*Math.Sin(rad)),y+(float)(2.824*Math.Cos(rad)));} Matrix GamePose(Layer l,bool fixedRig){
 int mode=fixedRig?0:Math.Max(0,motion.SelectedIndex),part=Array.IndexOf(rigParts,l.Part);
 if(part<0||l.Img==null)return new Matrix();
 double t=fixedRig?0:mode==1?frame*.60:frame,d=gameDuration[mode];
 t=(mode==3||mode>=5)?Math.Min(d,t):t%d;
 var samples=gameFrames[mode];double k=t/d*(samples.Length/51-1);int j=(int)k,next=Math.Min(j+1,samples.Length/51-1);float u=(float)(k-j);
 bool tail=part==0;int slot=tail?7:part;int a=j*51+slot*3,b=next*51+slot*3;
 float x=samples[a]+(samples[b]-samples[a])*u,y=samples[a+1]+(samples[b+1]-samples[a+1])*u,angle=samples[a+2]+(samples[b+2]-samples[a+2])*u;
 if(tail){var center=TailAt(x,y,angle);x=center.X;y=center.Y;angle-=23.576f;}float cx=l.X+l.Img.Width/2f,cy=l.Y+l.Img.Height/2f;
 var m=new Matrix();m.RotateAt(angle,new PointF(cx,cy),MatrixOrder.Append);m.Translate(x-cx,y-cy,MatrixOrder.Append);return m;
}

}



